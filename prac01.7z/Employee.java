import java.sql.*;
import java.util.*;
class Employee
{
	public static void main(String args[])
	{
		Connection con;
		Statement stmt;
		ResultSet rs;
		Scanner sc=new Scanner(System.in);

		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3308/Employee_master","root","");
			System.out.println("connected");
			stmt=con.createStatement();
			while(true)
			{
				System.out.println("1.view all record");
				System.out.println("2.Show record based on employee id");
				System.out.println("3.Show record based on employee code");
				System.out.println("4.Update specific record based on primary key.");
				System.out.println("5. Delete specific record based on primary key. ");
				System.out.println("6.Update specific record based on the field emp_code");
				System.out.println("7. Delete specific record based on the field emp_cod");
				System.out.println("Enter choice ");
				int ch=sc.nextInt();
				switch(ch)
				{
					case 1:
						String query="SELECT * FROM `emp_details`";
						rs=stmt.executeQuery(query);
						while(rs.next())
						{
							System.out.println(rs.getString(1)+"    "+rs.getString(2)+"   "+rs.getString(3)+"   "+rs.getString(4));
						}
						break;
					case 2:
						System.out.println("Enter employee id to show the record");
						String empid=sc.next();
						query="SELECT * FROM `emp_details` where emp_id="+empid;
						rs=stmt.executeQuery(query);
						while(rs.next())
						{
							System.out.println(rs.getString(1)+"    "+rs.getString(2)+"   "+rs.getString(3)+"   "+rs.getString(4));
						}
						break;
					case 3:
						System.out.println("Enter employee id to show the record");
						empid=sc.next();
						query="SELECT * FROM `emp_details` where emp_code='"+empid+"'";
						rs=stmt.executeQuery(query);
						while(rs.next())
						{
							System.out.println(rs.getString(1)+"    "+rs.getString(2)+"   "+rs.getString(3)+"   "+rs.getString(4)+"  "+rs.getString(5));
						}
						break;
					case 4:
						System.out.println("Enter employee id to show the record");
						empid=sc.next();
						System.out.println("Enter new mobile number to update");
						String mono=sc.next();
						query="UPDATE `emp_details` SET `emp_phone` = '"+mono+"' WHERE `emp_details`.`emp_id` = "+empid;
						int count=stmt.executeUpdate(query);
						if(count>0)
						{
							System.out.println("Record update");
						}
						else
						{
							System.out.println("Try again");
						}
						break;
					case 5:
						System.out.println("Enter employee id to show the record");
						empid=sc.next();

						query="DELETE FROM `emp_details` WHERE `emp_details`.`emp_id` = "+empid;
						count=stmt.executeUpdate(query);
						if(count>0)
						{
							System.out.println("Record deleted");
						}
						else
						{
							System.out.println("Try again");
						}
						break;
					case 6:
						System.out.println("Enter employee code to show the record");
						empid=sc.next();
						System.out.println("Enter new employee code");
						mono=sc.next();
						query="UPDATE `emp_details` SET `emp_code` = '"+mono+"' WHERE `emp_details`.`emp_code` ='"+empid+"'";
						count=stmt.executeUpdate(query);
						if(count>0)
						{
							System.out.println("Record update");
						}
						else
						{
							System.out.println("Try again");
						}
						break;
					case 7:
						System.out.println("Enter employee code to show the record");
						empid=sc.next();

						query="DELETE FROM `emp_details` WHERE `emp_details`.`emp_code` ='"+empid+"'";
						count=stmt.executeUpdate(query);
						if(count>0)
						{
							System.out.println("Record deleted");
						}
						else
						{
							System.out.println("Try again");
						}
						break;


				}
			}

		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}

}