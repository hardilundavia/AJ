import java.sql.*;
import java.util.*;
class EmployeeSalary
{
	public static void main(String args[])
	{
		Connection con;
		Statement stmt;
		ResultSet rs;
		Scanner sc=new Scanner(System.in);

		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3308/Employee_master","root","");
			System.out.println("connected");
			stmt=con.createStatement();
			while(true)
			{
				System.out.println("1.view all record");
				System.out.println("2.Show record based on employee id");
				System.out.println("Enter choice ");
				int ch=sc.nextInt();
				switch(ch)
				{
					case 1:
						String query="SELECT emp.emp_fname,emp.emp_id,emp.emp_code,emp1.emp_salry_gross,emp1.emp_salary_other FROM emp_details emp JOIN emp_salary_detail emp1 on emp.emp_id=emp1.emp_id";
						rs=stmt.executeQuery(query);
						while(rs.next())
						{
							System.out.println(rs.getString(2)+"    "+rs.getString(1)+"   "+rs.getString(3)+"   "+rs.getString(4)+"  "+rs.getString(5));
						}
						break;
					case 2:
						System.out.println("Enter employee id to show the record");
						String empid=sc.next();
						query="SELECT emp.emp_fname,emp.emp_id,emp.emp_code,emp1.emp_salry_gross,emp1.emp_salary_other FROM emp_details emp JOIN emp_salary_detail emp1 on emp.emp_id=emp1.emp_id WHERE emp.emp_code='"+empid+"'";
						rs=stmt.executeQuery(query);
						while(rs.next())
						{
							System.out.println(rs.getString(1)+"    "+rs.getString(2)+"   "+rs.getString(3)+"   "+rs.getString(4));
						}
						break;

				}
			}

		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}

}